<!--?php
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~// Kontaktformular.org
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Einstellungen
// Ihre E-Mailadresse
$ihre_emailadresse = 'cgennat@machbar-web.de';
// Absender || Muster(From: NAME <EMAIL-->
<html xmlns="http://www.raptorarts.de/machbar-web2.de">
  <head>
  </head>
  <body>) // Beispiel: 'From: Max Musterlise <max@musterlise.xx>'
      $email_absender = 'From: Kontaktformular <system@domain.tld>'; // Betreff
        $email_betreffzeile = 'Kontaktformular-Anfrage'; // Hinweismeldungen
        #Nicht alle Felder ausgef�llt $errormessage[0] = 'Fehler, Sie haben
        nicht alle Felder ausgef�llt:'; #Kein Name eingegeben $errormessage[1] =
        '<br>
        - Ung�ltiger Name'; #Ung�ltige E-Mailadresse eingegeben $errormessage[2]
        = '<br>
        - Ung�ltiger E-Mailadresse'; #Kein Betreff eingegeben $errormessage[3] =
        '<br>
        - Ung�ltiger Betreff'; #Keine Nachricht eingegeben $errormessage[4] = '<br>
        - Ung�ltige Nachricht'; #Ung�ltiger Sicherheitscode $errormessage[5] = '<br>
        - Ung�ltiger Sicherheitscode'; #Ung�ltiger Zeichen (Spamverdacht)
        $errormessage[6] = '<br>
        - Ung�ltige Zeichen entdeckt'; #Alle Felder sind OKi $okay = 'Vielen
        Dank f�r Ihre Nachricht, wir melden uns in den n�chsten Tagen gerne bei
        Ihnen. Ihr machbar Coach - Christian Gennat'<br>
        <br>
        '; //
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        ####################################### session_start();
        error_reporting(0); #######################################
        if(isset($_POST['submit'])) { #######################################
        $name = check($_POST['name']); $email = check($_POST['email']); $betreff
        = check($_POST['betreff']); $nachricht = check($_POST['nachricht']);
        $telefonnummer = check($_POST['telefonnummer']);
        ####################################### $ip = $_SERVER['REMOTE_ADDR'];
        $host = gethostbyaddr($ip); #######################################
        $zeit = time(); $datum = date ("d.m.Y", $zeit); $uhrzeit = date
        ("H:i:s", $zeit); ####################################### $message = '<span
          style="color:red">'
          . $errormessage[0]; if($name==''){$message .= $errormessage[1];
          $fehler = 1;}
          if(!preg_match('#^([a-zA-Z0-9\.\_\-]+)@([a-zA-Z0-9\.\-]+\.[A-Za-z][A-Za-z]{1,4})$#',
          $email)){ $message .= $errormessage[2]; $fehler = 1; }
          if($betreff==''){$message .= $errormessage[3]; $fehler = 1;}
          if($nachricht==''){$message .= $errormessage[4]; $fehler = 1;}
          if($_POST['code']=="" ||
          strtolower($_POST['code'])!=$_SESSION['captcha_code']){ $message .=
          $errormessage[5]; $fehler = 1;} if(ehi_check()!=0){$message .=
          $errormessage[6]; $fehler = 1;} $message .= '</span><br>
        <br>
        '; #######################################
        ####################################### if(!isset($fehler)){
        $email_nachricht = "-- Kontakformularanfrage --\n\nBetreff: $betreff";
        $email_nachricht .= "\nName: $name\nE-Mailadresse:
        $email\nTelefonnummer: $Telefonnummer\n\n"; $email_nachricht .=
        "Nachricht:\n$nachricht\n\nIP: $ip\nHost: $host\n"; $email_nachricht .=
        "gesendet am $datum um $uhrzeit."; // Mail senden
        @mail($ihre_emailadresse, $email_betreffzeile, $email_nachricht,
        $email_absender); //Variablen resetten $name = ''; $betreff = ''; $email
        = ''; $nachricht = ''; $homepage = ''; $meldung=$okay; } else {
        $meldung=$message; } #######################################
        ####################################### } //endissetsubmit
        else{$meldung='';} //
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        ?&gt;
        <title>Kontaktformular</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <meta http-equiv="content-style-type" content="text/css">
        <meta http-equiv="content-script-type" content="text/javascript">
        <style type="text/css">
body,td,th{font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;color:#333333;}
body{background-color: #FFFFFF;}
a:link, a:visited, a:active{color:#0066FF;text-decoration:none;}
a:hover{text-decoration: underline;}
</style> <script type="text/javascript">
function reload_captcha(){ 
var nd = new Date();
var src="captcha.php?"+nd;
document.getElementById("captcha").src= src;
}
</script> <p><strong>Kontaktformular:</strong></p>
        <form name="kontaktformular" action="&lt;?php echo $_SERVER['PHP_SELF']; ?&gt;"
          method="post">
          <table style="width:500px">
            <tbody>
              <tr>
                <td colspan="2"><?php echo $meldung; ?><br>
                </td>
              </tr>
              <tr>
                <td style="width:150px"><strong>Name:</strong></td>
                <td><input required="required" name="name" value="&lt;?php echo $name;	?&gt;"
                    size="40"
                    maxlength="100"
                    type="text"></td>
              </tr>
              <tr>
                <td style="width:150px"><strong>E-Mail Adresse:</strong></td>
                <td><input required="required" name="email" id="email" value="&lt;?php echo $email; ?&gt;"
                    size="40"
                    maxlength="100"
                    type="text"></td>
              </tr>
              <tr>
                <td style="width:150px"><strong>Betreff:</strong></td>
                <td><input name="betreff" value="&lt;?php echo $betreff; ?&gt;"
                    size="40"
                    maxlength="50"
                    type="text"></td>
              </tr>
              <tr>
                <td style="width:150px"><strong>Telefonnummer:</strong></td>
                <td><input autocomplete="off" name="telefonnummer" value="&lt;?php echo $telefonnummer; ?&gt;"
                    size="40"
                    maxlength="50"
                    type="text"></td>
              </tr>
              <tr>
                <td style="width:150px"><strong>Nachricht:</strong></td>
                <td><textarea name="nachricht" cols="40" rows="10" style="white-space: nowrap;">&lt;?php
                    echo $nachricht; ?&gt;</textarea></td>
              </tr>
              <tr>
                <td style="width:150px">&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td style="width:150px"><strong>Sicherheitscode:</strong></td>
                <td><img id="captcha" src="captcha.php" alt="captcha" border="1"><br>
                  <a href="javascript:void(0);" onclick="reload_captcha();">Neuer
                    Code?</a></td>
              </tr>
              <tr>
                <td style="width:150px"><strong>Sicherheitscode <br>
                    wiederholen: </strong></td>
                <td><input name="code" size="20" maxlength="50" type="text"></td>
              </tr>
              <tr>
                <td style="width:150px">&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td style="width:150px">&nbsp;</td>
                <td><input value="Abschicken" name="submit" type="submit">
                  <!-- Hinweis darf nicht entfernt werden! -->
                  <p><span style="font-size:10px; font-family:Verdana, Arial, Helvetica, sans-serif">
                      � Script Powered by <a target="_blank" href="http://www.kontaktformular.org"
                        title="kostenloses Kontaktformular">kostenloses
                        Kontaktformular</a></span></p>
                  <!-- Hinweis darf nicht entfernt werden! --></td>
              </tr>
            </tbody>
          </table>
        </form>
      </system@domain.tld> </max@musterlise.xx>
  </body>
</html>
<?php 
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

function check($var){$varsafe=trim(strip_tags($var));
return $varsafe;}

function ehi_check(){$achtung=0;
foreach($_POST as $val){$pos = strpos(strtolower($val), 'content-type:'); if($pos !== false){$achtung++;}
$pos = strpos(strtolower($val), 'content-type');  if($pos !== false){$achtung++;}$pos = strpos(strtolower($val), 'bcc:');          if($pos !== false){$achtung++;}
$pos = strpos(strtolower($val), 'bcc');           if($pos !== false){$achtung++;}} //endforeach
return $achtung;  // wenn Null dann Alles Okay} 

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
?>